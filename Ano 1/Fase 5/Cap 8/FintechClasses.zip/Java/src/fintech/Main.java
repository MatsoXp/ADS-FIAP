package fintech;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	
	private Scanner scanner;
	private List<PessoaPF> dadosPF;
	private List<PessoaPJ> dadosPJ;

	public static void main(String[] args) {
		
		Main c = new Main();
		c.main();
	}
	
	private void main() {
		
		boasVindas();
		
		scanner = new Scanner(System.in);
		dadosPF = new ArrayList<>();
		dadosPJ = new ArrayList<>();
		PessoaPF pf = new PessoaPF();
		PessoaPJ pj = new PessoaPJ();
		
		int opcao;
		String escolha;
		while (true) {
			opcao = menu();
			while (opcao < 1 || opcao > 5) {
				texto("Digite uma opção válida!");
				opcao = menu();
			}
			if (opcao == 1) {
				cadastroPF(scanner, pf);
			}
			else if (opcao == 2) {
				cadastroPJ(scanner, pj);

			}
			else if (opcao == 3) {
				texto("Digite (PJ) para consultar pessoa jurídica ou (PF) para consultar pessoa física: ");
				escolha = scanner.next().toUpperCase();
				while (!escolha.equals("PF") && !escolha.equals("PJ")) {
					textoNL("Escolha uma resposta válida!");
					texto("(PJ) para consultar pessoa física ou (PF) para consultar pessoas jurídica: ");
					escolha = scanner.next().toUpperCase();
				}
				if (escolha.equals("PF")) {
					scanner.nextLine();
					pf.consultarPessoaPF(dadosPF, scanner);
				}
				else if (escolha.equals("PJ")) {
					scanner.nextLine();
					pj.consultarPessoaPJ(dadosPJ, scanner);
				}
			}
			else if (opcao == 4) {
				System.out.print("Digite (PF) para excluir pessoas fisicas ou (PJ) para excluir pessoas juridicas: ");
				escolha = scanner.next().toUpperCase();
				while (!escolha.equals("PF") && !escolha.equals("PJ")) {
					textoNL("Escolha uma resposta válida!");
					texto("(PF) para consultar pessoa física ou (PJ) para consultar pessoas jurídica: ");
					escolha = scanner.next().toUpperCase();
				}
				if (escolha.equals("PF")) {
					scanner.nextLine();
					pf.deletarPessoaPF(dadosPF, scanner);
				}
				else if (escolha.equals("PJ")) {
					scanner.nextLine();
					pj.deletarPessoaPJ(dadosPJ, scanner);
				}
				
			}
			else {
				textoNL("Obrigado por usar nosso sistema, volte sempre!");
				scanner.close();
				break;
			}
		}		
	}
	
	private void cadastroPF(Scanner scanner, PessoaPF pf) {
		
		scanner.nextLine();
		pf.setCadastroPessoaPF(scanner);
		texto("Adicionar Cadastro (S\\N)?: ");
		String escolha = scanner.next();
		while (!escolha.equals("S") && !escolha.equals("N")) {
			textoNL("Escolha uma resposta válida!");
			texto("Adicionar Cadastro (S\\N)?: ");
			escolha = scanner.next().toUpperCase();
		}
		if (escolha.equalsIgnoreCase("S")) {
			textoNL("Cadastro adicionado com sucesso!");
			dadosPF.add(pf);
		}
		else {
			textoNL("Cadastro ignorado!");
		}
		
	}
	
	private void cadastroPJ(Scanner scanner, PessoaPJ pj) {
		
		scanner.nextLine();
		pj.setCadastroPessoaPJ(scanner);
		texto("Adicionar Cadastro (S\\N)?: ");
		String escolha = scanner.next();
		while (!escolha.equals("S") && !escolha.equals("N")) {
			textoNL("Escolha uma resposta válida!");
			texto("Adicionar Cadastro (S\\N)?: ");
			escolha = scanner.next().toUpperCase();
		}
		if (escolha.equalsIgnoreCase("S")) {
			textoNL("Cadastro adicionado com sucesso!");
			dadosPJ.add(pj);
		}
		else {
			textoNL("Cadastro ignorado!");
		}
		
	}

	private int menu() {
		textoNL("[ 1 ] - Cadastrar pessoa fisica");
		textoNL("[ 2 ] - Cadastrar pessoa juridica");
		textoNL("[ 3 ] - Consultar cadastro");
		textoNL("[ 4 ] - Deletar cadastro");
		textoNL("[ 5 ] - Sair do sistema");
		texto("Escolha uma Opção: ");
		return scanner.nextByte();
	}
	
	private void boasVindas() {
		
		textoNL("* * * * * * * * * * * * * * * * * * * * * * * * * * *");
		textoNL("*                   Insiders Tech                   *");
		textoNL("* * * * * * * * * * * * * * * * * * * * * * * * * * *\n");
		
		textoNL("Bem vindo ao sistema cadastro de usuários. \nFaça uma escolha abaixo:");
		textoNL("Escolha uma das opções abaixo.");
	}
	
	private void textoNL(String frase) {
		System.out.println(frase);
	}
	
	private void texto(String frase) {
		System.out.print(frase);
	}
}
