package fintech;

import java.util.List;
import java.util.Scanner;

public class PessoaPJ extends Pessoa{
	
	private String cnpj;
	private String nire;
	
	public PessoaPJ() {
		// TODO Auto-generated constructor stub
	}
	
	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getNire() {
		return nire;
	}

	public void setNire(String nire) {
		this.nire = nire;
	}

	public PessoaPJ setCadastroPessoaPJ(Scanner scanner) {
		
		PessoaPJ pj = new PessoaPJ();
		
		textoNL("Preencha os dados abaixo corretamente!");
		texto("Razão social: "); setNome(scanner.nextLine());
		texto("NIRE: "); setNire(scanner.nextLine());
		texto("Cnpj: "); setCnpj(scanner.nextLine());
		texto("Email: "); setEmail(scanner.nextLine());
		texto("Data abertura: "); setNascimento(scanner.nextLine());
		texto("Endereço: "); setEndereco(scanner.nextLine());
		texto("Bairro: "); setBairro(scanner.nextLine());
		texto("Cidade: "); setCidade(scanner.nextLine());
		texto("Estado: "); setEstado(scanner.nextLine());
		texto("Cep: "); setCep(scanner.nextLine());
		
		return pj;
	}
	
	public void consultarPessoaPJ(List<PessoaPJ> dadosPJ, Scanner scanner) {
		
		String	busca;
		int		encontrado;
		
		
		if (dadosPJ.size() == 0) {
			textoNL("Não existem cadastros!");
		}
		else {
			
			texto("Digite o CNPJ do cadastro: ");
			busca = scanner.next();
			
			encontrado = -1;
			PessoaPJ pj = dadosPJ.get(0);
			for (int i = 0; i < dadosPJ.size(); i++) {
			
				dadosPJ.get(i);
				if(busca.equals(pj.getCnpj())) {
					textoNL("Cadastro encontrado.");
					pj.getDadosPessoaPJ();
					encontrado = 1;
				}	
			}
			if (encontrado < 0)
				textoNL("Cadastro não foi encontrado, tente novamente!");
		}
	}
	
	public void getDadosPessoaPJ() {
		
		textoNL("Razão social: " + getNome());
		textoNL("Cnpj: " + getCnpj());
		textoNL("Nire: " + getNire());
		textoNL("Email: " + getEmail());
		textoNL("Data nascimento: " + getNascimento());
		textoNL("Endereço: " + getEndereco());
		textoNL("Bairro: " + getBairro());
		textoNL("Cidade: " + getCidade());
		textoNL("Estado: " + getEstado());
		textoNL("Cep: " + getCep());	
	
	}
	
public void deletarPessoaPJ(List<PessoaPJ> dadosPJ, Scanner scanner) {
		
		String busca;
		int encontrado;
		
		if (dadosPJ.size() == 0) {
			textoNL("Não existem cadastros!");
		}
		else {
			
			texto("Digite CNPJ do cadastro que deseja deletar: ");
			busca = scanner.next();
			
			encontrado = -1;
			PessoaPJ pj = dadosPJ.get(0);
			for (int i = 0; i < dadosPJ.size(); i++)
			{
				dadosPJ.get(i);
				if (busca.equals(pj.getCnpj())){
					System.out.println("Cadastro deletado!");
					dadosPJ.remove(i);
					encontrado = 1;
				}
			}
			if (encontrado < 0) {
				textoNL("Cadastro não foi encontrado, tente novamente!");
			}
			
		}
		
	}
	
	private void textoNL(String frase) {
		System.out.println(frase);
	}
	
	private void texto(String frase) {
		System.out.print(frase);
	}
}
