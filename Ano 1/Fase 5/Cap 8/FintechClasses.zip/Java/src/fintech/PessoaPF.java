package fintech;

import java.util.List;
import java.util.Scanner;

import fintech.PessoaPF;

public class PessoaPF extends Pessoa {
	
	private String	cpf;
	private String	rg;
	
	public PessoaPF() {
		// TODO Auto-generated constructor stub
	}
	
	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getRg() {
		return rg;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public PessoaPF setCadastroPessoaPF(Scanner scanner) {
		
		PessoaPF pf = new PessoaPF();
		textoNL("Preencha os dados abaixo corretamente!");
		texto("Nome: "); setNome(scanner.nextLine());
		texto("Rg: "); setRg(scanner.nextLine());
		texto("Cpf: "); setCpf(scanner.nextLine());
		texto("Email: "); setEmail(scanner.nextLine());
		texto("Data nascimento: "); setNascimento(scanner.nextLine());
		texto("Endereço: "); setEndereco(scanner.nextLine());
		texto("Bairro: "); setBairro(scanner.nextLine());
		texto("Cidade: "); setCidade(scanner.nextLine());
		texto("Estado: "); setEstado(scanner.nextLine());
		texto("Cep: "); setCep(scanner.nextLine());
		
		return pf;
		
	}	
	
	public void consultarPessoaPF(List<PessoaPF> dadosPF, Scanner scanner) {
		
		String	busca;
		int		encontrado;
		
		if (dadosPF.size() == 0) {
			textoNL("Não existem cadastros!");
		}
		else {
			
			texto("Digite o CPF do cadastro: ");
			busca = scanner.next();
			
			encontrado = -1;
			PessoaPF pf = dadosPF.get(0);
			for (int i = 0; i < dadosPF.size(); i++) {
			
				dadosPF.get(i);
				if(busca.equals(pf.getCpf())) {
					textoNL("Cadastro encontrado.");
					pf.getDadosPessoaPF();
					encontrado = 1;
				}	
			}
			if (encontrado < 0)
				textoNL("Cadastro não foi encontrado, tente novamente!");
		}
		
	}
		
	public void getDadosPessoaPF() {
			
			textoNL("Nome: " + getNome());
			textoNL("Rg: " + getRg());
			textoNL("Cpf: " + getCpf());
			textoNL("Email: " + getEmail());
			textoNL("Data nascimento: " + getNascimento());
			textoNL("Endereço: " + getEndereco());
			textoNL("Bairro: " + getBairro());
			textoNL("Cidade: " + getCidade());
			textoNL("Estado: " + getEstado());
			textoNL("Cep: " + getCep());	
		
	}
	
	public void deletarPessoaPF(List<PessoaPF> dadosPF, Scanner scanner) {
		
		String busca;
		int encontrado;
		
		if (dadosPF.size() == 0) {
			textoNL("Não existem cadastros!");
		}
		else {
			
			texto("Digite CPF do cadastro que deseja deletar: ");
			busca = scanner.next();
			
			encontrado = -1;
			PessoaPF pf = dadosPF.get(0);
			for (int i = 0; i < dadosPF.size(); i++)
			{
				dadosPF.get(i);
				if (busca.equals(pf.getCpf())){
					System.out.println("Cadastro deletado!");
					dadosPF.remove(i);
					encontrado = 1;
				}
			}
			if (encontrado < 0) {
				textoNL("Cadastro não foi encontrado, tente novamente!");
			}
			
		}
		
	}
	
	public void textoNL(String frase) {
		System.out.println(frase);
	}
	
	public void texto(String frase) {
		System.out.print(frase);
	}
}
