package br.com.fiap.gerencimed

import android.os.Bundle
import android.view.Menu
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import br.com.fiap.gerencimed.screens.Load
import br.com.fiap.gerencimed.screens.Login
import br.com.fiap.gerencimed.screens.MenuPrincipal
import br.com.fiap.gerencimed.screens.Register
import br.com.fiap.gerencimed.ui.theme.GerencimedTheme

/*
    navController: Guarda o histórico de navegação de toda a aplicação.
    startDestination: Resposável pelo ponto de start. (primeira tela a carregar)
*/
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GerencimedTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()
                    NavHost(
                        navController = navController,
                        startDestination = "load"
                    ) {
                        composable(route = "load") {
                            Load(navController)
                        }
                        composable(route = "login") {
                            Login(navController)
                        }
                        composable(route = "register") {
                            Register(navController)
                        }
                        composable(route = "menu") {
                            MenuPrincipal(navController)
                        }

                    }
                }
            }
        }
    }
}
