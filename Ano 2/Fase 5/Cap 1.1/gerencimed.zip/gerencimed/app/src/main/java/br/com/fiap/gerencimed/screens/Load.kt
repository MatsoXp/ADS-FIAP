package br.com.fiap.gerencimed.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.navigation.NavController
import br.com.fiap.gerencimed.R
import kotlinx.coroutines.delay

@Composable
fun Load(navController: NavController) {
    val delayMillis = 3000L

    LaunchedEffect(Unit) {
        delay(delayMillis)
        navController.navigate("login")
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(color = Color.White),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.gerencimed_logo_frase),
            contentDescription = "Gerencimed logo com frase"
        )
    }
}
