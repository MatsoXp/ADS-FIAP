package br.com.fiap.gerencimed.screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.modifier.modifierLocalConsumer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.ViewCompat
import androidx.navigation.NavController
import br.com.fiap.gerencimed.R
//import br.com.gerencimed.ui.theme.GerenciMedTheme
import kotlin.math.round



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuPrincipal(navController: NavController) {

    //Column com fundo branco tamanho surface
    Column(verticalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
    )
    {
        //cabecalho
        Row(modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
            //cor e bordas curvas do cabecalho
            .background(
                Color(0xFFC5FBDE),
                shape = RoundedCornerShape(
                    topStart = 0.dp,
                    topEnd = 0.dp,
                    bottomStart = 50.dp,
                    bottomEnd = 50.dp
                )
            )
        )
        {
            //img logo gerencimed
            Image(painter = painterResource(id = R.drawable.logo_gerencimed), contentDescription = "logotipo gerencimed",
                modifier = Modifier
                    .size(70.dp)
                    .padding(top = 15.dp)
            )

            //coluna com texto
            Column(
                horizontalAlignment = CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .padding(15.dp)

            )
            {
                //alterar fonte
                Text(
                    text = "GERENCIMED",
                    fontSize = 21.sp,
                    color = Color(0xFF36AA9B)
                )
                Text(
                    text = "TRANSFORMANDO DADOS EM SAÚDE",
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }

            //icone menu hamburguer
            Image(painter = painterResource(id = R.drawable.menu_hamburguer), contentDescription = "icone menu hamburguer",
                modifier = Modifier
                    .size(50.dp)
                    .padding(top = 20.dp)
            )

        }

        //barra pesquisa
        Row(modifier = Modifier
            .padding(15.dp)
            .fillMaxWidth()
        )

        {
            //campo texto barra pesquisa
            OutlinedTextField(modifier = Modifier.fillMaxWidth(),
                value = "",
                onValueChange = {},
                placeholder = {
                    Text(text = "Buscar: ")
                },
                trailingIcon = {
                    Icon(painter = painterResource(id = R.drawable.baseline_search_24), contentDescription = "icone de busca")

                }
            )

        }
//--------------------------------------------------------------------------------------------------------------------------------



        //especialistas
        Row {
            Text(modifier = Modifier
                .padding(5.dp),

                text = "Especialistas",
                textAlign = TextAlign.Left,
                fontSize = 21.sp,
                color = Color(0xFF9D9D9D)

            )
        }

        //lista de medicos
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
                .padding(bottom = 15.dp)

        )
        {
            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.foto_medico), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(120.dp)

                )
                Text(
                    text = "Dr. Lucas \r\n Ortopedista",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }


            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.foto_medico), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(120.dp)
                    //.padding(top = 20.dp)
                )
                Text(
                    text = "Dr. Fernando \r\n Dermatologista",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }

            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.foto_medico), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(120.dp)

                )
                Text(
                    text = "Dr. Marcos \r\n Cardiologista",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }
        }


//---------------------------------------------------------------------------------------------------------------------

        //funcionalidades agendamento / historico / exames / receitas
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
                .padding(bottom = 20.dp)

        )
        {
            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.calendario), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(16.dp))

                )
                Text(
                    text = "Agendamento",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }


            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.historico), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(16.dp))

                )
                Text(
                    text = "Histórico de \r\n consultas",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }

            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.exames), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
                Text(
                    text = "Exames",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }

            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.receitas), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
                Text(
                    text = "Receitas",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = Color(0xFF503320)
                )
            }
        }

//*******************************************************************************************************************************

        //lista de medicos
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()

        )
        {

            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.avaliar1), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(190.dp, 90.dp)

                )
            }

            Column(horizontalAlignment = CenterHorizontally,
                modifier = Modifier

            )

            {
                Image(painter = painterResource(id = R.drawable.avaliar1), contentDescription = "foto do medico",
                    modifier = Modifier
                        .size(190.dp, 90.dp)

                )
            }
        }


        Spacer(modifier = Modifier.weight(1f))

//******************************************************************************************************************************
        //barra rodapé
        Row(
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically,

            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)

                //cor e bordas curvas do cabecalho
                .background(
                    Color(0xFFC5FBDE),

                    )
        )


        {
            Image(painter = painterResource(id = R.drawable.home), contentDescription = "logotipo gerencimed",
                modifier = Modifier
                    .size(140.dp)
                //.padding(top = 15.dp)
            )
            Image(painter = painterResource(id = R.drawable.upar), contentDescription = "logotipo gerencimed",
                modifier = Modifier
                    .size(80.dp)
                //.padding(top = 15.dp)
            )
            Image(painter = painterResource(id = R.drawable.icone_medico), contentDescription = "logotipo gerencimed",
                modifier = Modifier
                    .size(75.dp)
                //.padding(top = 5.dp)
            )
            Image(painter = painterResource(id = R.drawable.configuracoes), contentDescription = "logotipo gerencimed",
                modifier = Modifier
                    .size(75.dp)
                //.padding(top = 5.dp)
            )

        }

    }

}


