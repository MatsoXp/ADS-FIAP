from flask import Flask, request, jsonify
import oracledb

app = Flask(__name__)

# Função para buscar todas as pessoas
def buscar_todas_as_pessoas():
    try:
        # conexão oracle
        conexao = oracledb.connect(user='RM94092', password='300797', dsn='(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=oracle.fiap.com.br)(PORT=1521)))(CONNECT_DATA=(SID=ORCL)))')
        cursor = conexao.cursor()

        sql = """
            SELECT NOME, SOBRENOME, IDADE, CRIME
            FROM T_PROCURADOS
        """

        cursor.execute(sql)
        resultados = cursor.fetchall()

        pessoas = []

        for resultado in resultados:
            pessoa = {
                'nome': resultado[0],
                'sobrenome': resultado[1],
                'idade': resultado[2],
                'crime': resultado[3]
            }
            pessoas.append(pessoa)

        return pessoas

    except oracledb.DatabaseError as e:
        error, = e.args
        print("Erro ao buscar pessoas no banco de dados:")
        print(error.message)
        return None

    finally:
        if cursor:
            cursor.close()
        if conexao:
            conexao.close()

# Função para buscar pessoas por nome
def buscar_pessoas_por_nome(nome):
    try:
        # conexão oracle
        conexao = oracledb.connect(user='RM94092', password='300797', dsn='(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=oracle.fiap.com.br)(PORT=1521)))(CONNECT_DATA=(SID=ORCL)))')
        cursor = conexao.cursor()

        # SQL para buscar pessoas pelo NOME
        sql = """
            SELECT NOME, SOBRENOME, IDADE, CRIME
            FROM T_PROCURADOS
            WHERE UPPER(NOME) = UPPER(:nome)
        """

        cursor.execute(sql, {'nome': nome})
        resultados = cursor.fetchall()

        pessoas = []

        for resultado in resultados:
            pessoa = {
                'nome': resultado[0],
                'sobrenome': resultado[1],
                'idade': resultado[2],
                'crime': resultado[3]
            }
            pessoas.append(pessoa)

        return pessoas

    except oracledb.DatabaseError as e:
        error, = e.args
        print("Erro ao buscar pessoas no banco de dados:")
        print(error.message)
        return None

    finally:
        if cursor:
            cursor.close()
        if conexao:
            conexao.close()

# Função para buscar pessoas por nome completo
def buscar_pessoas_por_nome_completo(nome, sobrenome):
    try:
        # conexão oracle
        conexao = oracledb.connect(user='RM94092', password='300797', dsn='(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=oracle.fiap.com.br)(PORT=1521)))(CONNECT_DATA=(SID=ORCL)))')
        cursor = conexao.cursor()

        # SQL para buscar pessoas pelo NOME e SOBRENOME
        sql = """
            SELECT NOME, SOBRENOME, IDADE, CRIME
            FROM T_PROCURADOS
            WHERE UPPER(NOME) = UPPER(:nome)
            AND UPPER(SOBRENOME) = UPPER(:sobrenome)
        """

        cursor.execute(sql, {'nome': nome, 'sobrenome': sobrenome})
        resultados = cursor.fetchall()

        pessoas = []

        for resultado in resultados:
            pessoa = {
                'nome': resultado[0],
                'sobrenome': resultado[1],
                'idade': resultado[2],
                'crime': resultado[3]
            }
            pessoas.append(pessoa)

        return pessoas

    except oracledb.DatabaseError as e:
        error, = e.args
        print("Erro ao buscar pessoas no banco de dados:")
        print(error.message)
        return None

    finally:
        if cursor:
            cursor.close()
        if conexao:
            conexao.close()

# Rota da API para buscar todas as pessoas
@app.route('/buscar', methods=['GET'])
def buscar_todas():
    todas_as_pessoas = buscar_todas_as_pessoas()
    if todas_as_pessoas:
        return jsonify(todas_as_pessoas)
    else:
        return jsonify({'mensagem': 'Nenhum registro encontrado.'})

# Rota da API para buscar pessoas por nome
@app.route('/buscar_nome', methods=['GET'])
def buscar_nome():
    nome = request.args.get('nome')
    if nome:
        pessoas_encontradas = buscar_pessoas_por_nome(nome)
        if pessoas_encontradas:
            return jsonify(pessoas_encontradas)
        else:
            return jsonify({'mensagem': 'Nenhuma pessoa encontrada com o nome informado.'})
    else:
        return jsonify({'mensagem': 'Informe o nome para buscar.'})

# Rota da API para buscar pessoas por nome completo
@app.route('/buscar_nomecompleto', methods=['GET'])
def buscar_nome_completo():
    nome = request.args.get('nome')
    sobrenome = request.args.get('sobrenome')
    if nome and sobrenome:
        pessoas_encontradas = buscar_pessoas_por_nome_completo(nome, sobrenome)
        if pessoas_encontradas:
            return jsonify(pessoas_encontradas)
        else:
            return jsonify({'mensagem': 'Nenhuma pessoa encontrada com o nome e sobrenome informados.'})
    else:
        return jsonify({'mensagem': 'Informe o nome e sobrenome para buscar.'})

if __name__ == '__main__':
    app.run(debug=True)
