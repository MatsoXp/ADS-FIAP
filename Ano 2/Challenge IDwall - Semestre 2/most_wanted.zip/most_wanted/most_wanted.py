import oracledb
import requests
import json

# Função para inserir dados no banco
def inserir_dados_banco(registros, fonte):
    try:
        # Criar uma instância de cursor
        cursor = conexao.cursor()

        #pega os dados da API, primeiro identifica se é da interpol ou fbi, e dps os parametros de cada uma
        for procurado in registros:
            if fonte == 'Interpol':
                nome = procurado.get('name', '')
                sobrenome = procurado.get('forename', '')
                crime_url = procurado.get('_links', {}).get('self', {}).get('href', '')
                crime = detalhes_crime(crime_url)
                idade = procurado.get('date_of_birth', '')
            else:
                nome = procurado.get('title', '').split(' ')[0]
                sobrenome = procurado.get('title', '').split(' ')[1]
                crime = procurado.get('description', '')
                idade = procurado.get('age_max', None)
                if idade is None:
                    idade = procurado.get('age_range', None)

            # Inserire os dados na tabela T_PROCURADOS
            cursor.execute("""
                INSERT INTO T_PROCURADOS (NOME, SOBRENOME, IDADE, CRIME, FONTE)
                VALUES (:nome, :sobrenome, :idade, :crime, :fonte)
            """, {'nome': nome, 'sobrenome': sobrenome, 'idade': idade, 'crime': crime, 'fonte': fonte})
        
        # Commit no banco
        conexao.commit()
        
        print(f"Página da API {fonte} adicionada à tabela T_PROCURADOS.")
    
    except oracledb.DatabaseError as e:
        error, = e.args
        print("Erro ao inserir dados no banco:")
        print(error.message)
    finally:
        # Fechar o cursor
        if cursor:
            cursor.close()

# Função para obter detalhes do crime
def detalhes_crime(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            data = json.loads(response.content)
            arrest_warrants = data.get('arrest_warrants', [])
            if arrest_warrants and 'charge' in arrest_warrants[0]:
                charge = arrest_warrants[0]['charge']
            else:
                charge = ''
            return charge
        else:
            print("Erro ao obter detalhes do crime:", response.status_code)
            return ''
    except Exception as e:
        print("Erro ao obter detalhes do crime:", str(e))
        return ''

# Conexão Oracle
dsn_tns = oracledb.makedsn('oracle.fiap.com.br', '1521', sid='ORCL')
usuario = 'RM94092'
senha = '300797'

try:
    conexao = oracledb.connect(user=usuario, password=senha, dsn=dsn_tns)
    print("Conexão bem-sucedida com o banco de dados Oracle!")

except oracledb.DatabaseError as e:
    error, = e.args
    print("Erro ao conectar ao banco de dados Oracle:")
    print(error.message)

# SQL para verificar se a tabela T_PROCURADOS existe
sql_check_table = """
    SELECT count(*) FROM user_tables WHERE table_name = 'T_PROCURADOS'
"""

# SQL para criar a tabela T_PROCURADOS 
sql_create_table = """
    CREATE TABLE T_PROCURADOS (
        ID NUMBER GENERATED ALWAYS AS IDENTITY,
        NOME VARCHAR2(255),
        SOBRENOME VARCHAR2(255),
        IDADE VARCHAR2(50),
        CRIME VARCHAR2(1500),
        FONTE VARCHAR2(50),
        CONSTRAINT PK_T_PROCURADOS PRIMARY KEY (ID)
    )
"""

try:
    # Criar uma instância de cursor
    cursor = conexao.cursor()

    # Verificar se a tabela já existe
    cursor.execute(sql_check_table)
    tabela_existe = cursor.fetchone()[0]

    if tabela_existe:
        # Se a tabela existir, dropá-la
        cursor.execute("DROP TABLE T_PROCURADOS")
        print("Tabela T_PROCURADOS dropada.")

    # Criar a tabela T_PROCURADOS
    cursor.execute(sql_create_table)

    # Commit no banco
    conexao.commit()

    print("Tabela T_PROCURADOS criada com sucesso.")

    # API da Interpol, limita numero de registros e controla quantos foram retornados até o max_registros_interpol
    max_registros_interpol = 50
    registros_obtidos_interpol = 0
    url_base_interpol_api = 'https://ws-public.interpol.int/notices/v1/red'
    pagina_interpol = 1

    while registros_obtidos_interpol < max_registros_interpol:
        url_interpol_api = f'{url_base_interpol_api}?page={pagina_interpol}&resultPerPage=50'

        response_interpol = requests.get(url_interpol_api)

        if response_interpol.status_code == 200:
            data_interpol = json.loads(response_interpol.content)
            total_registros_interpol = data_interpol.get('total', 0)
            registros_pagina_atual_interpol = len(data_interpol.get('_embedded', {}).get('notices', []))

            # confere se existem mais registros na proxima pagina
            if registros_pagina_atual_interpol == 0:
                break  # Se não houver, break

            # registros até o limite definido em max_registros_interpol
            registros_a_adicionar_interpol = min(max_registros_interpol - registros_obtidos_interpol, registros_pagina_atual_interpol)

            registros_para_adicionar_interpol = data_interpol.get('_embedded', {}).get('notices', [])[:registros_a_adicionar_interpol]

            inserir_dados_banco(registros_para_adicionar_interpol, 'Interpol')

            registros_obtidos_interpol += registros_a_adicionar_interpol
            pagina_interpol += 1  # próxima página

        else:
            print("Falha na requisição à API da Interpol:", response_interpol.status_code)
            break  #se a requisição falhar, break

    # API do FBI
    max_registros_fbi = 50
    registros_obtidos_fbi = 0
    url_base_fbi_api = 'https://api.fbi.gov/@wanted?pageSize=50&sort_on=modified&sort_order=desc'
    pagina_fbi = 2

    while registros_obtidos_fbi < max_registros_fbi:
        url_fbi_api = f'{url_base_fbi_api}&page={pagina_fbi}'

        response_fbi = requests.get(url_fbi_api)

        if response_fbi.status_code == 200:
            data_fbi = json.loads(response_fbi.content)
            total_registros_fbi = data_fbi.get('total', 0)
            registros_pagina_atual_fbi = len(data_fbi.get('items', []))

            # ver se há mais registros na próxima página
            if registros_pagina_atual_fbi == 0:
                break  # se não houver, break

            # registros até o limite definido em max_registros_fbi
            registros_a_adicionar_fbi = min(max_registros_fbi - registros_obtidos_fbi, registros_pagina_atual_fbi)

            registros_para_adicionar_fbi = data_fbi.get('items', [])[:registros_a_adicionar_fbi]

            inserir_dados_banco(registros_para_adicionar_fbi, 'FBI')

            registros_obtidos_fbi += registros_a_adicionar_fbi
            pagina_fbi += 1  # próxima página

        else:
            print("Falha na requisição à API do FBI:", response_fbi.status_code)
            break  # Se a solicitação falhar, break

except oracledb.DatabaseError as e:
    error, = e.args
    print("Erro ao criar a tabela T_PROCURADOS ou inserir dados.")
    print(error.message)
finally:
    # Fechar o cursor e a conexão
    if cursor:
        cursor.close()
    if conexao:
        conexao.close()
