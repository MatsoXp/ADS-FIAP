Precisei abreviar/reduzir o nome das tabelas, na hora de exportar os scripts foram apontados alguns erros relacionados ao limite de 30 caracteres.

Optei por não coletar dados como endereço, telefone e CPF, não vejo utilidade para o projeto no momento, estaria armazenando dados importantes sem ter um propósito.

T_USUARIO
ds_email e ds_senha são os dados utilizados para autenticar o usuário.

T_OBJETIVO_FINANCEIRO
Qual a intenção/objetivo do cliente com o aplicativo, ex:quitar dividas, começar a poupar, investir e etc. não é a opção de criar "metas".(pode ser alterado no app)

T_MOVIMENTACAO
registra o "evento do usuário", ato de selecionar no app a opção de registrar algum lançamento, cria um id único para aquele lançamento.

T_TIPO_MOVIMENTACAO
identifica o tipo do lançamento, se é um crédito, débito, investimento, etc

T_CATEGORIA_MOVIMENTACAO
categoriza o lançamento, se for um crédito, pode ser de aluguel, salário, uma venda, etc.

T_META_DESCRICAO
Categoriza e adiciona os dados da meta, como comprar um carro de 70.000,00 em 01/01/2023